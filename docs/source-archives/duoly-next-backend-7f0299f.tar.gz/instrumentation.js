// Runs once when the site's server starts: brings the Discord bot online (lib/discordBot.js), keeps the
// Teammate / Online / In Session server roles in sync (lib/discordRoles.js) and posts orders nobody took
// in the game channels (lib/discordQueue.js), and keeps the EUR → USD rate current (lib/fx.js).
// The imports sit inside the NEXT_RUNTIME check so they're left out of the edge build (no file access there).
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { startBot } = await import('./lib/discordBot');
    const { startRoleSync } = await import('./lib/discordRoles');
    const { startQueuePosts } = await import('./lib/discordQueue');
    const { startFx } = await import('./lib/fx');
    startFx(); // daily EUR → USD rate
    startBot();
    startRoleSync();
    startQueuePosts();
  }
}
