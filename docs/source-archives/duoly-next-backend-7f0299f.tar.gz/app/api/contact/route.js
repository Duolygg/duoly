import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { cookies } from 'next/headers';
import { currentUser } from '@/lib/apiUser';
import { currentConversation, startConversation, addMessage, updateConversation, refreshWho, clean } from '@/lib/support';
import { notifyAdmins } from '@/lib/supportTeam';

export const dynamic = 'force-dynamic';
// same cookie as the support chat (app/api/support), so a guest sees the team's answer in their chat bubble
const COOKIE = 'dl_support';
const TOPICS = { order: 'Order help', payment: 'Payments & refunds', teammate: 'Becoming a teammate', privacy: 'Privacy & data', business: 'Business & partnerships', creator: 'Creator program application', other: 'Something else' };

// a little spam protection: 3 messages per person per 10 minutes
const G = globalThis.__duolyContact || (globalThis.__duolyContact = new Map());
const LIMIT = 3, WINDOW = 10 * 60000;

// The contact form (/contact). The message lands in the support inbox like a chat that asked for a human:
// admins see it under Support, get the @Admin ping on Discord, and their reply shows up in the sender's
// support chat (and they have the email to write back).
export async function POST(req) {
  const body = await req.json().catch(() => ({}));
  if (body.website) return NextResponse.json({ ok: true }); // honeypot: bots fill every field
  const user = await currentUser();
  const jar = cookies();
  let guestId = jar.get(COOKIE)?.value;
  const fresh = !user && (!guestId || !/^[A-Za-z0-9_-]{16,40}$/.test(guestId));
  if (fresh) guestId = crypto.randomBytes(18).toString('base64url');

  const name = clean(body.name, 60) || (user && user.name) || '';
  const email = clean(body.email, 120).toLowerCase() || (user && user.email) || '';
  const topic = TOPICS[body.topic] ? body.topic : 'other';
  const order = clean(body.order, 20).toUpperCase();
  const message = clean(body.message, 2000);
  if (name.length < 2) return NextResponse.json({ error: 'Tell us your name.', field: 'name' }, { status: 400 });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return NextResponse.json({ error: 'That email doesn’t look right.', field: 'email' }, { status: 400 });
  if (message.length < 10) return NextResponse.json({ error: 'Write a little more so we can help (at least 10 characters).', field: 'message' }, { status: 400 });

  const key = user ? 'u' + user.id : 'g' + guestId;
  const now = Date.now();
  const recent = (G.get(key) || []).filter((t) => now - t < WINDOW);
  if (recent.length >= LIMIT) return NextResponse.json({ error: 'You’ve sent a few messages already. We’ll get back to you, or try again in a few minutes.' }, { status: 429 });
  G.set(key, recent.concat([now]));

  const who = user
    ? { userId: user.id, role: user.teammate ? 'teammate' : 'customer', name: user.name || name, email: user.email || email, image: user.image || '' }
    : { guestId, role: 'guest', name, email };
  let c = await currentConversation(who);
  if (!c) c = await startConversation(who);
  refreshWho(c, who);
  addMessage(c, 'user', '📨 Contact form · ' + TOPICS[topic] + (order ? ' · Order ' + order : '') + '\n' + message + (user ? '' : '\n— ' + name + ' · ' + email));
  addMessage(c, 'bot', 'Thanks, ' + name.split(' ')[0] + '! Your message is with the team. They’ll answer right here in this chat, and they have your email (' + email + ') if you’re not around.');
  updateConversation(c, { status: c.status === 'open' ? 'open' : 'waiting', waitingSince: c.waitingSince && c.status !== 'closed' ? c.waitingSince : now });
  notifyAdmins((topic === 'creator' ? '🎥 **New creator application**' : '📨 **New contact form message**') + ' from **' + name + '** (' + (user ? (user.teammate ? 'teammate' : 'customer') : 'guest') + ' · ' + email + ')\nTopic: **' + TOPICS[topic] + '**' + (order ? ' · Order **' + order + '**' : '') + '\n> ' + message.slice(0, 300).replace(/\n/g, '\n> ') + '\nReply in the admin dashboard → Support chat (' + (process.env.NEXTAUTH_URL || '') + '/admin#support)')
    .then((note) => { if (note) updateConversation(c, { discordNote: note }); })
    .catch(() => {});

  const res = NextResponse.json({ ok: true, id: c.id });
  if (fresh) res.cookies.set(COOKIE, guestId, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 365 * 86400 });
  return res;
}
