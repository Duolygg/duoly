import { NextResponse } from 'next/server';
import { checkSignup, createUser } from '@/lib/users';

// Creates an email + password account. The client logs in right after.
export async function POST(req) {
  let body;
  try {
    body = await req.json();
  } catch (e) {
    return NextResponse.json({ error: 'Invalid request.' }, { status: 400 });
  }
  const problem = checkSignup(body || {});
  if (problem) return NextResponse.json({ error: problem }, { status: 400 });
  const { user, error } = await createUser(body);
  if (error) return NextResponse.json({ error }, { status: 409 });
  return NextResponse.json({ user }, { status: 201 });
}
