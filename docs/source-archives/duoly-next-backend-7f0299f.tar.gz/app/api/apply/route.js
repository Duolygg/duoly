import { NextResponse } from 'next/server';
import { submitApplication } from '@/lib/applications';

export const dynamic = 'force-dynamic';

// Teammate application from /apply (no account needed). Admins review it under Teammates → Applications.
export async function POST(req) {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== 'object') return NextResponse.json({ error: 'Invalid request.' }, { status: 400 });
  const res = await submitApplication(body);
  if (res.error) return NextResponse.json({ error: res.error }, { status: res.status });
  return NextResponse.json(res, { status: 201 });
}
