import { NextResponse } from 'next/server';
import { fxInfo } from '@/lib/fx';

export const dynamic = 'force-dynamic';

// The current EUR → USD rates, for showing USD prices in the browser (public, no personal data).
export async function GET() {
  return NextResponse.json(fxInfo(), { headers: { 'cache-control': 'public, max-age=300' } });
}
