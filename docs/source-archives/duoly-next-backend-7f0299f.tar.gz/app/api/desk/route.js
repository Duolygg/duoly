import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { deskState, teammateActive } from '@/lib/orders';
import { heartbeat } from '@/lib/presence';
import { effectivePrio } from '@/lib/penalty';
import { accessOf, discordOf, accountState } from '@/lib/roles';

export const dynamic = 'force-dynamic';

// Teammate and admin dashboards poll this every few seconds: it records that they're online
// and returns the shared order queue (plus their own active order).
export async function POST(req) {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  if (!user.teammate && !user.admin) return fail('Only teammates can open the order desk.', 403);
  const body = await req.json().catch(() => ({}));
  // teammates have to connect Discord before they can go online (the bot shows them as Online / In Session)
  const needDiscord = !user.admin && !(await discordOf(user.id));
  // a suspended teammate can't go online (admin decision, Teammates tab)
  const suspended = user.admin ? null : (await accountState(user.id)).suspended;
  const online = user.admin ? true : !!body.online && !needDiscord && !suspended; // admins are always online
  // the games admins see on the live desk: only ones this teammate is approved for (Gamer Girls: any game)
  const access = user.admin ? null : await accessOf(user.id);
  const games = (Array.isArray(body.games) ? body.games : []).filter((g) => !access || access.gg || access.games.includes(g));
  const { forcedOffline } = heartbeat(user, { online, lastActive: body.lastActive, games });
  if (forcedOffline) return NextResponse.json({ forcedOffline });
  // offline, but they may still own an order (e.g. claimed through a handover link)
  if (!online) return NextResponse.json({ offline: true, needDiscord, suspended: suspended ? { reason: suspended.reason } : null, mine: await teammateActive(user.id) });
  return NextResponse.json(await deskState(user, { admin: user.admin, prio: await effectivePrio(user) }));
}
