import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { allAccounts, setRole, setAccess } from '@/lib/roles';
import { knownUsers, forceOffline } from '@/lib/presence';
import { activeOrderFor } from '@/lib/orders';

export const dynamic = 'force-dynamic';

// Admins: every account and its role.
export async function GET() {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const online = new Map(knownUsers().map((u) => [u.id, u]));
  const accounts = (await allAccounts()).map((a) => ({
    id: a.id, name: a.name, email: a.email, image: a.image || '', provider: a.provider || '',
    role: a.role, owner: a.owner, you: a.id === user.id,
    roleBy: a.roleBy || '', roleAt: a.roleAt || null, firstSeen: a.firstSeen || null, lastSeen: a.lastSeen || null,
    access: a.access, // games they may take, or Gamer Girl (lib/access.js)
    online: !!(online.get(a.id) && online.get(a.id).online)
  }));
  return NextResponse.json({ accounts });
}

// { userId, role } — make someone a customer, teammate or admin.
// { userId, access: { games, gg } } — which orders a teammate may take. Applies on their next queue poll.
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  if (body.access) {
    const res = await setAccess(String(body.userId || ''), body.access, user);
    if (res.error) return fail(res.error, res.status);
    return NextResponse.json(res);
  }
  if (body.role !== 'teammate' && (await activeOrderFor(String(body.userId || '')))) return fail('They’re playing an order right now. Change their role once it’s finished.', 409);
  const res = await setRole(String(body.userId || ''), body.role, user);
  if (res.error) return fail(res.error, res.status);
  // no longer a teammate: take them off the order desk right away
  if (res.account.role !== 'teammate') forceOffline(res.account.id, 'Your role changed', user.name || user.email);
  return NextResponse.json(res);
}
