import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { allReports, decideReport, REPORT_TYPES, BOUNTY } from '@/lib/reports';

export const dynamic = 'force-dynamic';

// Admins: customer reports against teammates (with screenshot evidence) and the bounty decision.
export async function GET() {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const reports = (await allReports()).map((r) => ({ ...r, typeLabel: REPORT_TYPES[r.type] || r.type }));
  return NextResponse.json({ reports, bounty: BOUNTY });
}

// { id, decision: 'approved' | 'rejected', note }
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const res = await decideReport(String(body.id || ''), body.decision, user, body.note);
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res);
}
