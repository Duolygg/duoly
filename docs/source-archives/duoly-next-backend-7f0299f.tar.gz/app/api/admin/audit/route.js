import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { addAudit, recentAudit } from '@/lib/audit';

export const dynamic = 'force-dynamic';

// Admins: the audit log (newest first), and adding an entry for an action just taken.
export async function GET() {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  return NextResponse.json({ audit: await recentAudit() });
}

// { action, target, detail }; who and when come from the server
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const entry = await addAudit(user, body);
  if (!entry) return fail('Missing action.', 400);
  return NextResponse.json({ entry });
}
