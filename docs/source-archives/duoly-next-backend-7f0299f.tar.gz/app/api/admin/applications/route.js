import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { allAccounts, setRole, setAccess } from '@/lib/roles';
import { allApplications, decideApplication } from '@/lib/applications';

export const dynamic = 'force-dynamic';

// Admins: approve or reject a teammate application. { id, decision: 'approve' | 'reject', reason }
// Approving makes the Duoly account with the applicant's email a teammate for that game.
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const app = (await allApplications()).find((a) => a.id === body.id);
  if (!app) return fail('Application not found.', 404);
  const by = user.name || user.email;
  if (body.decision === 'reject') {
    const r = await decideApplication(app.id, 'Rejected', by, { reason: String(body.reason || '').slice(0, 120) });
    return r.error ? fail(r.error, r.status) : NextResponse.json({ application: r.application });
  }
  if (body.decision !== 'approve') return fail('Unknown decision.', 400);
  const account = (await allAccounts()).find((a) => String(a.email || '').toLowerCase() === app.email);
  let note = '';
  if (account && account.role === 'customer') {
    const r = await setRole(account.id, 'teammate', user);
    if (r.error) return fail(r.error, r.status);
    await setAccess(account.id, { games: [app.game], gg: false }, user);
    note = 'teammate';
  } else if (account) note = account.role; // already a teammate or admin
  else note = 'no-account';
  const r = await decideApplication(app.id, 'Approved', by, { accountId: account ? account.id : null });
  return r.error ? fail(r.error, r.status) : NextResponse.json({ application: r.application, result: note });
}
