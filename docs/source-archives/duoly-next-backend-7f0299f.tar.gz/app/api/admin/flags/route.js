import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { reviewFlag } from '@/lib/flags';

export const dynamic = 'force-dynamic';

// Admins: review a message the chat filter stopped. { id, status: 'Warned' | 'Dismissed' }
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const res = await reviewFlag(String(body.id || ''), body.status, user.name || user.email);
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res);
}
