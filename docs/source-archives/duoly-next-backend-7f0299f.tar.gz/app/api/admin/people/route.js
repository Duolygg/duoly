import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { allAccounts, setSuspended, setBlocked, adjustWallet } from '@/lib/roles';
import { addAdjustment } from '@/lib/adjustments';
import { forceOffline } from '@/lib/presence';
import { activeOrderFor } from '@/lib/orders';
import { adminTeammates, adminCustomers } from '@/lib/adminPeople';

export const dynamic = 'force-dynamic';

// Admins: act on a teammate or customer account. Everything is saved on the account.
// { userId, action: 'suspend' | 'unsuspend' | 'block' | 'unblock' | 'balance', reason, amount }
// balance: + or − amount. Customers: their wallet in EUR (can't go below 0). Teammates: what they're owed in USD,
// added to this payout week (lib/adjustments.js).
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const target = (await allAccounts()).find((a) => a.id === body.userId);
  if (!target) return fail('Account not found.', 404);
  const by = user.name || user.email;
  let res;
  if (body.action === 'suspend' || body.action === 'unsuspend') {
    if (target.role !== 'teammate') return fail('Only teammates can be suspended.', 409);
    if (body.action === 'suspend' && await activeOrderFor(target.id)) return fail('They’re playing an order. Let it finish (or cancel it in Orders) first.', 409);
    res = await setSuspended(target.id, body.action === 'suspend', body.reason, by);
    if (body.action === 'suspend') forceOffline(target.id, 'Suspended: ' + String(body.reason || '').slice(0, 80), by);
  } else if (body.action === 'block' || body.action === 'unblock') {
    if (target.role !== 'customer') return fail('Only customers can be blocked.', 409);
    res = await setBlocked(target.id, body.action === 'block', body.reason, by);
  } else if (body.action === 'balance' || body.action === 'credit') {
    if (target.role === 'customer') {
      const now = (await adminCustomers()).find((c) => c.id === target.id);
      const amount = Math.round(Number(body.amount) * 100) / 100;
      if (now && now.wallet + amount < 0) return fail('That would take their wallet below €0. They have €' + now.wallet.toFixed(2) + '.', 400);
      res = await adjustWallet(target.id, amount, body.reason, by);
    } else if (target.role === 'teammate') {
      res = await addAdjustment(target, body.amount, body.reason, by);
    } else return fail('Admins have no balance.', 409);
  } else return fail('Unknown action.', 400);
  if (res.error) return fail(res.error, res.status);
  const list = target.role === 'teammate' ? await adminTeammates() : await adminCustomers();
  return NextResponse.json({ account: list.find((a) => a.id === target.id) });
}
