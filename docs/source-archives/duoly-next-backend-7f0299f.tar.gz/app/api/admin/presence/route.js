import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { onlineList, forceOffline } from '@/lib/presence';
import { activeOrderFor } from '@/lib/orders';
import { prioBreakdown } from '@/lib/penalty';

export const dynamic = 'force-dynamic';

// Admins: who's online right now (teammates and admins), and what they're playing.
export async function GET() {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const list = await Promise.all(onlineList().map(async (u) => {
    const o = await activeOrderFor(u.id);
    const b = await prioBreakdown(u);
    return { id: u.id, name: u.name, email: u.email, image: u.image, admin: u.admin, prio: b.effective, basePrio: b.base, adj: b.adj, penalty: b.penalty, missed: b.misses.length, since: u.since, lastActive: u.lastActive, games: u.games, order: o ? { id: o.id, title: o.title, games: o.games, unit: o.unit || 'game', game: o.game } : null };
  }));
  return NextResponse.json({ now: Date.now(), online: list });
}

// Admins: switch a teammate offline (e.g. AFK with the dashboard left open).
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  if (!body.userId) return fail('Missing userId.', 400);
  if (await activeOrderFor(body.userId)) return fail('They’re playing an order. It has to be finished first.', 409);
  const ok = forceOffline(body.userId, String(body.reason || 'Set offline by an admin').slice(0, 120), user.name);
  if (!ok) return fail('They’re not online any more.', 409);
  return NextResponse.json({ ok: true });
}
