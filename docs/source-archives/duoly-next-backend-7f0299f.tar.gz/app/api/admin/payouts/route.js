import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { payoutAction, payoutRows } from '@/lib/payouts';

export const dynamic = 'force-dynamic';

// { action: 'pay' | 'hold' | 'release' | 'payAll', id, reason } → the updated payout list
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const res = await payoutAction(String(body.action || ''), String(body.id || ''), user, body.reason);
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json({ ...res, payouts: await payoutRows() });
}
