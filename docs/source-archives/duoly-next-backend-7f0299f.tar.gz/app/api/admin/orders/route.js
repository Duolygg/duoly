import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { adminCancel, adminRefund } from '@/lib/orders';

export const dynamic = 'force-dynamic';

// Admins: { id, action: 'cancel' | 'refund', reason }. The money goes back to the customer's Duoly wallet.
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const reason = String(body.reason || '').trim();
  if (!reason) return fail('Add a reason. It goes into the audit log.', 400);
  const res = body.action === 'cancel' ? await adminCancel(String(body.id || ''), user, reason)
    : body.action === 'refund' ? await adminRefund(String(body.id || ''), user, reason)
      : { error: 'Unknown action.', status: 400 };
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res);
}
