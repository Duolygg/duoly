import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { allConversations, conversationById, addMessage, updateConversation, clean } from '@/lib/support';
import { adminTeammates, adminCustomers } from '@/lib/adminPeople';
import { customerActive } from '@/lib/orders';
import { updateAdminNote } from '@/lib/supportTeam';

export const dynamic = 'force-dynamic';

// Admin support inbox. GET: every conversation (newest activity first); ?id=… adds the full chat and
// who the person is. POST: { id, action: 'reply', text } · 'claim' · 'bot' (hand back to Sparky) · 'close' · 'seen'.
const summary = (c) => {
  const last = c.messages[c.messages.length - 1];
  return {
    id: c.id, role: c.role, name: c.name, email: c.email, image: c.image, status: c.status, agent: c.agent,
    updatedAt: c.updatedAt, waitingSince: c.status === 'waiting' ? c.waitingSince || c.updatedAt : null,
    preview: last ? (last.from === 'admin' ? (last.by ? last.by.name : 'Admin') + ': ' : last.from === 'bot' ? 'Sparky: ' : '') + last.text.slice(0, 90) : '',
    // only chats a human is needed in count as unread (Sparky handles the rest)
    unread: c.status === 'waiting' || c.status === 'open' ? c.messages.filter((m) => m.from === 'user' && m.at > (c.adminSeenAt || 0)).length : 0,
    count: c.messages.length,
    // what the person last wrote (for the admin's browser notification)
    lastUserText: ((c.messages.filter((m) => m.from === 'user').slice(-1)[0] || {}).text || '').slice(0, 160)
  };
};

async function details(c) {
  let context = null;
  if (c.role === 'teammate') {
    const t = (await adminTeammates()).find((x) => x.id === c.userId);
    if (t) context = { kind: 'teammate', tier: t.tier, games: t.games, gg: t.gg, owed: t.owed, rating: t.rating, lifetime: t.lifetime, status: t.status, suspended: !!t.suspended, discord: t.discord };
  } else if (c.role === 'customer') {
    const cu = (await adminCustomers()).find((x) => x.id === c.userId);
    const active = await customerActive({ id: c.userId });
    if (cu) context = { kind: 'customer', wallet: cu.wallet, orders: cu.orders, level: cu.level, blocked: !!cu.blocked, order: active.order ? { id: active.order.id, status: active.order.status, title: active.order.title, games: active.order.games, game: active.order.game } : null };
  }
  return { ...summary(c), messages: c.messages, context };
}

export async function GET(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const id = new URL(req.url).searchParams.get('id');
  const list = await allConversations();
  const open = id ? list.find((c) => c.id === id) : null;
  return NextResponse.json({ now: Date.now(), conversations: list.slice(0, 200).map(summary), open: open ? await details(open) : null });
}

export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const c = await conversationById(String(body.id || ''));
  if (!c) return fail('Chat not found.', 404);
  const me = { id: user.id, name: String(user.name || user.email || 'Admin').split(' ')[0], image: user.image || '' };
  const hadAgent = !!(c.status === 'open' && c.agent);
  if (body.action === 'reply') {
    const text = clean(body.text, 2000);
    if (!text) return fail('Write a reply first.', 400);
    if (c.status === 'closed') addMessage(c, 'system', me.name + ' reopened the chat.');
    addMessage(c, 'admin', text, me);
    updateConversation(c, { status: 'open', agent: c.agent || me, adminSeenAt: Date.now() });
  } else if (body.action === 'claim') {
    addMessage(c, 'system', me.name + ' joined the chat.');
    updateConversation(c, { status: 'open', agent: me, adminSeenAt: Date.now() });
  } else if (body.action === 'bot') {
    addMessage(c, 'system', me.name + ' handed the chat back to Sparky.');
    updateConversation(c, { status: 'bot', agent: null });
  } else if (body.action === 'close') {
    addMessage(c, 'system', me.name + ' closed the chat. Write again anytime.');
    updateConversation(c, { status: 'closed' });
  } else if (body.action === 'seen') {
    updateConversation(c, { adminSeenAt: Date.now() });
  } else return fail('Unknown action.', 400);
  // keep the @Admin note in Discord up to date, so nobody else picks up a chat that's taken care of
  const note = c.discordNote;
  if (note && note.messageId) {
    const status = (body.action === 'reply' || body.action === 'claim') && !hadAgent ? '✅ **' + me.name + '** is on it'
      : body.action === 'close' ? '✔️ Closed by **' + me.name + '**'
        : body.action === 'bot' ? '↩️ **' + me.name + '** handed it back to Sparky' : null;
    if (status && status !== note.status) updateAdminNote(note, status).then((ok) => { if (ok) updateConversation(c, { discordNote: { ...note, status } }); });
  }
  return NextResponse.json({ open: await details(c) });
}
