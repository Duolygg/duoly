import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { adminStats } from '@/lib/orders';
import { payoutRows } from '@/lib/payouts';
import { adminTeammates, adminCustomers } from '@/lib/adminPeople';
import { allApplications } from '@/lib/applications';
import { allFlags } from '@/lib/flags';
import { allReports } from '@/lib/reports';
import { allConversations } from '@/lib/support';

export const dynamic = 'force-dynamic';

// Admins: everything the admin dashboard shows, all real (orders.json, the ledger, accounts,
// applications, flagged chat messages and customer reports).
export async function GET() {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const now = Date.now();
  const [stats, payouts, teammates, customers, applications, flags, reports, chats] = await Promise.all([
    adminStats(now), payoutRows(now), adminTeammates(now), adminCustomers(now), allApplications(), allFlags(), allReports(), allConversations()
  ]);
  // support chats waiting for a human (sidebar counter)
  const supportWaiting = chats.filter((c) => c.status === 'waiting' || (c.status === 'open' && c.messages.some((m) => m.from === 'user' && m.at > (c.adminSeenAt || 0)))).length;
  return NextResponse.json({ now, ...stats, payouts, teammates, customers, applications, flags, reportsOpen: reports.filter((r) => r.status === 'open').length, supportWaiting });
}
