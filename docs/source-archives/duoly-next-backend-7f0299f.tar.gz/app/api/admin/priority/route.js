import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { allAccounts } from '@/lib/roles';
import { knownUsers } from '@/lib/presence';
import { allPrios, setPrio, resetPrio, defaultPrio, clampPrio, forgiveMisses, isCustom, setAdjustment, clearAdjustment } from '@/lib/priority';
import { prioBreakdown, MISS_PENALTY, MISS_CAP, MISS_DAYS } from '@/lib/penalty';

export const dynamic = 'force-dynamic';

// Everyone who sees orders: teammates and admins (customers don't get orders, so they have no priority).
// Each with the full breakdown: base − buff/nerf + missed-order penalty = the seconds actually used.
async function accounts() {
  const prios = await allPrios();
  const online = new Map(knownUsers().map((u) => [u.id, u]));
  return Promise.all((await allAccounts())
    .filter((a) => a.role === 'teammate' || a.role === 'admin')
    .map(async (a) => {
      const saved = isCustom(prios[a.id]) ? prios[a.id] : null;
      const live = online.get(a.id);
      const b = await prioBreakdown({ id: a.id, admin: a.role === 'admin' });
      return {
        id: a.id, name: a.name, email: a.email, image: a.image || (live && live.image) || '', online: !!(live && live.online),
        admin: a.role === 'admin', prio: b.base, custom: !!saved,
        changedBy: saved ? saved.by : '', changedAt: saved ? saved.at : null,
        adj: b.adj, penalty: b.penalty, misses: b.misses.slice(0, 10), missed: b.misses.length, effective: b.effective
      };
    }));
}

export async function GET() {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  return NextResponse.json({ now: Date.now(), default: defaultPrio(), accounts: await accounts(), rules: { perMiss: MISS_PENALTY, cap: MISS_CAP, days: MISS_DAYS } });
}

// { userId, prio }                     set the base priority (0–100)
// { userId, reset: true }              base back to the default
// { userId, adjust, duration, reason } give a buff/nerf tier (lib/prioTiers.js)
// { userId, clearAdjust: true }        remove the buff/nerf
// { userId, forgive: true }            forgive missed orders
// Every answer returns the account's new breakdown.
export async function POST(req) {
  const user = await currentUser();
  if (!user || !user.admin) return fail('Admins only.', 403);
  const body = await req.json().catch(() => ({}));
  const account = (await accounts()).find((a) => a.id === body.userId);
  if (!account) return fail('Account not found.', 404);
  const by = user.name || user.email;
  if (body.forgive) await forgiveMisses(account.id, by);
  else if (body.clearAdjust) await clearAdjustment(account.id);
  else if (body.adjust) {
    const r = await setAdjustment(account, body.adjust, body.duration, body.reason, by);
    if (r.error) return fail(r.error, r.status);
  } else if (body.reset) await resetPrio(account.id);
  else {
    if (!Number.isFinite(Number(body.prio))) return fail('Priority must be a number from 0 to 100.', 400);
    await setPrio(account, clampPrio(body.prio), by);
  }
  return NextResponse.json({ account: (await accounts()).find((a) => a.id === account.id) });
}
