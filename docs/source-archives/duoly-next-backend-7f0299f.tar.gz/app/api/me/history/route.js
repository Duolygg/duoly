import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { customerHistory } from '@/lib/orders';

export const dynamic = 'force-dynamic';

// The signed-in customer's order history, wallet, stats and teammates (customer dashboard).
export async function GET() {
  const user = await currentUser();
  if (!user) return fail('Sign in first.', 401);
  return NextResponse.json(await customerHistory(user));
}
