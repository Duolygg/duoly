import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { saveProfile } from '@/lib/roles';
import { isCountry } from '@/lib/countries';
import { saveAvatar, removeAvatar } from '@/lib/avatars';

// Saves the signed-in user's profile. Body: any of { name, country, bio, languages, image },
// plus optional upload: a data URL of the new picture (cropped to 256×256 in the browser).
export async function POST(req) {
  const user = await currentUser();
  if (!user) return fail('Sign in first.', 401);
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== 'object') return fail('Nothing to save.', 400);

  const patch = {};
  ['name', 'country', 'image'].forEach((k) => { if (k in body) patch[k] = body[k]; });
  // bio and languages are shown to customers, so only teammates have them
  if (user.teammate) ['bio', 'languages'].forEach((k) => { if (k in body) patch[k] = body[k]; });

  let uploaded = '';
  if (body.upload) {
    const r = await saveAvatar(user.id, body.upload);
    if (r.error) return fail(r.error, 400);
    uploaded = r.url;
    patch.image = r.url;
  }

  const res = await saveProfile(user, patch, { isCountry });
  if (res.error) {
    if (uploaded) await removeAvatar(uploaded);
    return fail(res.error, res.status || 400);
  }
  // the old upload isn't used anywhere any more
  if ('image' in patch && res.previousImage !== res.profile.image) await removeAvatar(res.previousImage);
  return NextResponse.json({ profile: res.profile });
}
