import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { setCurrency, CURRENCIES } from '@/lib/roles';

// Saves the signed-in user's display currency on their account.
export async function POST(req) {
  const user = await currentUser();
  if (!user) return fail('Sign in first.', 401);
  const { currency } = await req.json().catch(() => ({}));
  if (!CURRENCIES.includes(currency)) return fail('Unknown currency.', 400);
  await setCurrency(user, currency);
  return NextResponse.json({ currency });
}
