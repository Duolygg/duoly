import { promises as fs } from 'fs';
import path from 'path';
import { DIR, FILE_RE, mimeOf } from '@/lib/avatars';

// Serves uploaded profile pictures. File names are random and never reused, so they can be cached forever.
export async function GET(req, { params }) {
  const file = String(params.file || '');
  if (!FILE_RE.test(file)) return new Response('Not found', { status: 404 });
  try {
    const buf = await fs.readFile(path.join(DIR, file));
    return new Response(buf, {
      headers: {
        'Content-Type': mimeOf(file),
        'Cache-Control': 'public, max-age=31536000, immutable',
        'X-Content-Type-Options': 'nosniff'
      }
    });
  } catch (e) {
    return new Response('Not found', { status: 404 });
  }
}
