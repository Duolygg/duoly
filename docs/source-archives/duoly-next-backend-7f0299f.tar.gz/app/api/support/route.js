import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { cookies } from 'next/headers';
import { currentUser } from '@/lib/apiUser';
import { currentConversation, startConversation, addMessage, updateConversation, refreshWho, clean } from '@/lib/support';
import { reply, greeting, CHIPS } from '@/lib/sparky';
import { supportTeam, notifyAdmins } from '@/lib/supportTeam';

export const dynamic = 'force-dynamic';
const COOKIE = 'dl_support';

// Who's chatting: a signed-in customer / teammate, or a guest (kept apart by a random cookie).
async function whoIsIt() {
  const user = await currentUser();
  if (user) {
    const role = user.teammate ? 'teammate' : 'customer';
    return { who: { userId: user.id, role, name: user.name || '', email: user.email || '', image: user.image || '' } };
  }
  const jar = cookies();
  let guestId = jar.get(COOKIE)?.value;
  const fresh = !guestId || !/^[A-Za-z0-9_-]{16,40}$/.test(guestId);
  if (fresh) guestId = crypto.randomBytes(18).toString('base64url');
  return { who: { guestId, role: 'guest', name: 'Guest' }, setCookie: fresh ? guestId : null };
}

// What the widget gets: the conversation (if any), the real admins, and the quick questions for this person.
function view(c, who, team) {
  return {
    role: who.role, chips: CHIPS[who.role] || CHIPS.guest, greeting: greeting(who),
    team,
    conversation: c ? {
      id: c.id, status: c.status, agent: c.agent,
      messages: c.messages.map((m) => ({ id: m.id, from: m.from, text: m.text, at: m.at, by: m.by ? { name: m.by.name, image: m.by.image } : null }))
    } : null
  };
}
function answer(body, setCookie) {
  const res = NextResponse.json(body);
  if (setCookie) res.cookies.set(COOKIE, setCookie, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 365 * 86400 });
  return res;
}

export async function GET() {
  const { who, setCookie } = await whoIsIt();
  const [c, team] = await Promise.all([currentConversation(who), supportTeam()]);
  if (c) refreshWho(c, who);
  return answer(view(c, who, team), setCookie);
}

// { text } a message · { action: 'human' } get a human · { action: 'close' } end the chat (next message starts a new one)
export async function POST(req) {
  const { who, setCookie } = await whoIsIt();
  const body = await req.json().catch(() => ({}));
  let c = await currentConversation(who);
  const team = await supportTeam();

  if (body.action === 'close') {
    if (c) { addMessage(c, 'system', 'You ended this chat.'); updateConversation(c, { status: 'closed' }); }
    return answer(view(null, who, team), setCookie);
  }

  const text = clean(body.text, 1000);
  const wantsHuman = body.action === 'human';
  if (!text && !wantsHuman) return answer({ error: 'Type a message first.' }, setCookie);
  if (!c) {
    c = await startConversation(who);
    addMessage(c, 'bot', greeting(who));
  }
  refreshWho(c, who);
  // a little flood protection
  const recent = c.messages.filter((m) => m.from === 'user' && Date.now() - m.at < 60000).length;
  if (recent >= 15) return NextResponse.json({ error: 'Slow down a little, then try again.' }, { status: 429 });
  if (text) addMessage(c, 'user', text);

  if (c.status === 'bot') {
    const r = wantsHuman ? { handoff: true } : await reply(who, text);
    if (r.handoff) {
      const online = team.filter((a) => a.online);
      addMessage(c, 'bot', online.length
        ? 'Got it! I’ve asked the team. ' + online.map((a) => a.name).slice(0, 3).join(', ') + (online.length === 1 ? ' is' : ' are') + ' online and will reply right here, usually within a few minutes.'
        : 'Got it! I’ve let the team know. Nobody is online this very minute, but your chat is saved and they’ll reply right here as soon as they’re back.');
      updateConversation(c, { status: 'waiting', waitingSince: Date.now() });
      // the Discord note is remembered on the chat, so it can say "fxbi is on it" later (app/api/admin/support)
      notifyAdmins('🙋 **' + (who.role === 'guest' ? 'A guest' : (who.role === 'teammate' ? 'Teammate ' : 'Customer ') + (who.name || '')) + '** wants to talk to the team' + (text && !/human|admin|agent|person/i.test(text) ? ': “' + text.slice(0, 200) + '”' : '') + '\nReply in the admin dashboard → Support chat (' + (process.env.NEXTAUTH_URL || '') + '/admin#support)').then((note) => { if (note) updateConversation(c, { discordNote: note }); });
    } else {
      addMessage(c, 'bot', r.text);
      if (r.chips) c.lastChips = r.chips;
    }
  } else if (c.status === 'closed') {
    updateConversation(c, { status: 'waiting', waitingSince: Date.now() });
  }
  // (waiting / open: an admin answers, Sparky stays quiet)
  const out = view(c, who, team);
  // quick answers Sparky suggests after this reply (the widget shows them under its message)
  if (c.lastChips) { out.suggest = c.lastChips; delete c.lastChips; }
  return answer(out, setCookie);
}
