import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { placeOrder, customerActive } from '@/lib/orders';

export const dynamic = 'force-dynamic';

// Customers: their open order (or one that just finished), for the dashboard.
export async function GET() {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  return NextResponse.json(await customerActive(user));
}

// Customers: put an order into the shared queue. Needs an account so the order belongs to someone.
export async function POST(req) {
  const user = await currentUser();
  if (!user) return fail('Please log in to queue.', 401);
  const body = await req.json().catch(() => ({}));
  const res = await placeOrder(user, body || {});
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res, { status: res.existing ? 200 : 201 });
}
