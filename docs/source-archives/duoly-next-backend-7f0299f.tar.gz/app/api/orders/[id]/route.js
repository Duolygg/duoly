import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { accept, complete, createHandover, customerOrder, customerCancel, review, reroll, report } from '@/lib/orders';
import { effectivePrio } from '@/lib/penalty';

export const dynamic = 'force-dynamic';

// The customer's waiting page polls this for their own order.
export async function GET(req, { params }) {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  const res = await customerOrder(params.id, user);
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res);
}

// One order:
//  teammates: accept it, complete it (with screenshot proof)
//  the customer who placed it: cancel while waiting, re-roll the teammate, report them, review + tip afterwards
//  admins: create a handover link
export async function POST(req, { params }) {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  const body = await req.json().catch(() => ({}));
  const id = params.id;
  // playing orders is for teammates (admins only route them, customers only book)
  if (['accept', 'complete'].includes(body.action) && !user.teammate) return fail(user.admin ? 'Admins don’t play orders. Send a handover link to a teammate instead.' : 'Only teammates can take orders.', 403);
  let res;
  if (body.action === 'accept') res = await accept(id, user, { prio: await effectivePrio(user) });
  else if (body.action === 'complete') res = await complete(id, user, { proof: body.proof });
  else if (body.action === 'cancel') res = await customerCancel(id, user);
  else if (body.action === 'review') res = await review(id, user, body);
  else if (body.action === 'reroll') res = await reroll(id, user);
  else if (body.action === 'report') res = await report(id, user, body);
  else if (body.action === 'handover') {
    if (!user.admin) return fail('Admins only.', 403);
    res = await createHandover(id, user);
    if (res.token) res.url = new URL('/claim/' + res.token, req.url).toString();
  } else return fail('Unknown action.', 400);
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res);
}
