import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { chatFor, postChat } from '@/lib/orders';

export const dynamic = 'force-dynamic';

// Order chat between the customer and the teammate who took the order. Both sides poll this.
export async function GET(req, { params }) {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  const res = await chatFor(params.id, user);
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res);
}

// { text } sends a message, { typing: true } says "I'm typing".
export async function POST(req, { params }) {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  const body = await req.json().catch(() => ({}));
  const res = await postChat(params.id, user, body || {});
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res);
}
