import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { statsFor, leaderboard } from '@/lib/ledger';
import { adjustmentsFor } from '@/lib/adjustments';

export const dynamic = 'force-dynamic';
const DAY = 86400000;

// The teammate dashboard's real numbers: earnings, held deposit, trust level, rating, reviews,
// plus the leaderboard (all teammates, by period and game). Only the teammate's own money is included.
// Manual adjustments by admins count in their earnings (never as orders), with the reason.
export async function GET() {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  if (!user.teammate) return fail('Teammates only.', 403);
  const now = Date.now();
  const [stats, board, adj] = await Promise.all([statsFor(user.id, now), leaderboard(now), adjustmentsFor(user.id)]);
  const recentAdj = adj.filter((a) => now - a.at < 8 * DAY);
  stats.recent = stats.recent.concat(recentAdj.map((a) => ({ orderId: null, at: a.at, net: a.amount, tip: 0, game: null, adjustment: true })));
  stats.adjustments = adj.filter((a) => now - a.at < 30 * DAY).reverse().map((a) => ({ amount: a.amount, reason: a.reason, at: a.at }));
  return NextResponse.json({ now, me: user.id, stats, leaderboard: board });
}
