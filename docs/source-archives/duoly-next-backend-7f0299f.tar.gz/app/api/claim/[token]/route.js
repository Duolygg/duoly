import { NextResponse } from 'next/server';
import { currentUser, fail } from '@/lib/apiUser';
import { claimInfo, claim } from '@/lib/orders';
import { accessOf } from '@/lib/roles';
import { canTake, whyNot } from '@/lib/access';
import { gameOf } from '@/lib/games';

export const dynamic = 'force-dynamic';

// Handover links: see the order, then accept it. Teammates only.
export async function GET(req, { params }) {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  if (!user.teammate) return fail('Only teammates can use handover links.', 403);
  const info = await claimInfo(params.token);
  // an order this teammate isn't approved for (wrong game, or Gamer Girl vs regular): say so before they try
  if (info.state === 'open') {
    const access = await accessOf(user.id);
    if (!canTake(info.order, access)) return NextResponse.json({ state: 'blocked', reason: whyNot(info.order, access, gameOf(info.order.game).name), order: info.order, by: info.by });
  }
  return NextResponse.json(info);
}

export async function POST(req, { params }) {
  const user = await currentUser();
  if (!user) return fail('Please log in.', 401);
  if (!user.teammate) return fail('Only teammates can use handover links.', 403);
  const res = await claim(params.token, user);
  if (res.error) return fail(res.error, res.status);
  return NextResponse.json(res);
}
