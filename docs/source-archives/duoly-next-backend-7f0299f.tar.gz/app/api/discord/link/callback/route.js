import { NextResponse } from 'next/server';
import { currentUser } from '@/lib/apiUser';
import { linkDiscord } from '@/lib/roles';
import { syncRolesSoon, linkCallbackUrl } from '@/lib/discordRoles';

export const dynamic = 'force-dynamic';

// Discord sends the user back here after "Authorize". We swap the code for their Discord id and save it.
export async function GET(req) {
  const [state, uid, next] = String(req.cookies.get('dl_discord_state')?.value || '').split('.');
  const back = (result) => {
    const res = NextResponse.redirect(new URL((next === 'teammate' ? '/teammate' : '/profile') + '?discord=' + result, req.url));
    res.cookies.set('dl_discord_state', '', { path: '/api/discord', maxAge: 0 });
    return res;
  };
  const q = new URL(req.url).searchParams;
  const user = await currentUser();
  if (!user) return NextResponse.redirect(new URL('/?login=/profile', req.url));
  if (q.get('error')) return back('cancelled');
  if (!state || state !== q.get('state') || uid !== user.id || !q.get('code')) return back('failed');

  try {
    const tok = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID, client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code', code: q.get('code'), redirect_uri: linkCallbackUrl(req)
      })
    }).then((r) => r.json());
    if (!tok.access_token) { console.error('[discord link] token exchange failed', tok.error || tok); return back('failed'); }
    const me = await fetch('https://discord.com/api/v10/users/@me', { headers: { authorization: 'Bearer ' + tok.access_token } }).then((r) => r.json());
    if (!me.id) return back('failed');
    const saved = await linkDiscord(user.id, { id: me.id, username: me.global_name || me.username });
    if (saved.error) return back('taken');
    syncRolesSoon();
    return back('linked');
  } catch (e) {
    console.error('[discord link] failed', e);
    return back('failed');
  }
}
