import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { currentUser } from '@/lib/apiUser';
import { unlinkDiscord } from '@/lib/roles';
import { syncRolesSoon, linkCallbackUrl } from '@/lib/discordRoles';

export const dynamic = 'force-dynamic';

// Connect Discord: sends the signed-in user to Discord to approve (scope "identify": only their id and name),
// Discord sends them back to ./callback. The state cookie makes sure the answer belongs to this browser.

export async function GET(req) {
  const user = await currentUser();
  if (!user) return NextResponse.redirect(new URL('/?login=/profile', req.url));
  if (!process.env.DISCORD_CLIENT_ID) return NextResponse.redirect(new URL('/profile?discord=unavailable', req.url));
  const state = crypto.randomBytes(18).toString('base64url');
  // where to come back to afterwards: the dashboard (from the connect popup) or the profile
  const next = new URL(req.url).searchParams.get('next') === '/teammate' ? 'teammate' : 'profile';
  const url = new URL('https://discord.com/oauth2/authorize');
  url.search = new URLSearchParams({ client_id: process.env.DISCORD_CLIENT_ID, response_type: 'code', scope: 'identify', redirect_uri: linkCallbackUrl(req), state, prompt: 'none' }).toString();
  const res = NextResponse.redirect(url);
  res.cookies.set('dl_discord_state', state + '.' + user.id + '.' + next, { httpOnly: true, sameSite: 'lax', secure: req.url.startsWith('https:'), path: '/api/discord', maxAge: 600 });
  return res;
}

// Disconnect: the bot takes the Online / In Session roles away on its next sync.
export async function DELETE() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Sign in first.' }, { status: 401 });
  await unlinkDiscord(user.id);
  syncRolesSoon();
  return NextResponse.json({ ok: true });
}
