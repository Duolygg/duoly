import { promises as fs } from 'fs';
import path from 'path';
import { currentUser } from '@/lib/apiUser';
import { uploadAllowed } from '@/lib/orders';
import { DIR, FILE_RE, MIME } from '@/lib/uploads';

export const dynamic = 'force-dynamic';

// Private screenshots (order proof, report evidence). Only people involved in the order, and admins.
export async function GET(req, { params }) {
  const file = String(params.file || '');
  const user = await currentUser();
  if (!user || !FILE_RE.test(file) || !(await uploadAllowed(file, user))) return new Response('Not found', { status: 404 });
  try {
    const buf = await fs.readFile(path.join(DIR, file));
    return new Response(buf, { headers: { 'Content-Type': MIME[file.split('.').pop()], // never cached: on a shared computer the next person signed in must not see it from the cache
      'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
  } catch (e) {
    return new Response('Not found', { status: 404 });
  }
}
